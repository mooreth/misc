import pygame
import os
import time

from lammps import lammps

lmp =lammps(cmdargs=["-screen", "none",  "-nocite"])

lmp.file("C:\LAMMPS\wall test\start_wall.input")


pygame.init()

#initialise the joystick module
pygame.joystick.init()

#define screen size
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 500

#create game window
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Joysticks")

#define font
font_size = 30
font = pygame.font.SysFont("Futura", font_size)

#function for outputting text onto the screen
def draw_text(text, font, text_col, x, y):
  img = font.render(text, True, text_col)
  screen.blit(img, (x, y))

#create clock for setting game frame rate
clock = pygame.time.Clock()
FPS = 5

#create empty list to store joysticks
joysticks = []

#create player rectangle
x = 350
y = 200
player = pygame.Rect(x, y, 100, 100)

#define player colour
col = "royalblue"


def moveposX():
  print("command to move positive X")
  block1 = """  
  label loop
  fix movegroup_fix pushgroup move linear 5.0 0.0 0.0
  dump $a all custom 3000 ball.$a.lammpstrj id mol x y z    
  run 3000
  undump $a
  next a
  unfix movegroup_fix
  jump SELF loop
  
  """
  lmp.commands_string(block1)  
  #wait()

def movenegX():
  print("command to move negative X")
  block2 = """
  label loop
  fix movegroup_fix pushgroup move linear -5.0 0.0 0.0
  dump $a all custom 3000 ball.$a.lammpstrj id mol x y z    
  run 3000
  undump $a
  next a
  unfix movegroup_fix
  jump SELF loop
  
  """
 
  lmp.commands_string(block2)  
  #wait()
  
def moveposY():
  print("command to move positive Y")
  block3 = """
  label loop
  fix movegroup_fix pushgroup move linear 0.0 5.0 0.0
  dump $a all custom 3000 ball.$a.lammpstrj id mol x y z    
  run 3000
  undump $a
  next a
  unfix movegroup_fix
  jump SELF loop
  
  """
  lmp.commands_string(block3)  
  #wait()
  

def movenegY():
  print("command to move negative Y")  
  block4 = """
     label loop
     fix movegroup_fix pushgroup move linear 0.0 -5.0 0.0
     dump $a all custom 3000 ball.$a.lammpstrj id mol x y z    
     run 3000
     undump $a
     next a
     unfix movegroup_fix
     jump SELF loop
     
     """
  lmp.commands_string(block4) 
  #wait()
  
def moveposZ():
  print("command to move positive Z")
  block5 = """
  label loop
  fix movegroup_fix pushgroup move linear 0.0 0.0 5.0
  dump $a all custom 3000 ball.$a.lammpstrj id mol x y z    
  run 3000
  undump $a
  next a
  unfix movegroup_fix
  jump SELF loop
  
  """
  lmp.commands_string(block5)  
  #wait()
  
def movenegZ():
  print("command to move negative Z")  
  block6 = """
  label loop
  fix movegroup_fix pushgroup move linear 0.0 0.0 -5.0
  dump $a all custom 3000 ball.$a.lammpstrj id mol x y z    
  run 3000
  undump $a
  next a
  unfix movegroup_fix
  jump SELF loop
  
  """
  lmp.commands_string(block6)
  #wait()
  
def wait():
    print("command to wait")
    block7 =  """
    label loop
    fix movegroup_fix pushgroup move linear 0.0 0.0 0.0
    dump $a all custom 3000 ball.$a.lammpstrj id mol x y z    
    run 8000
    undump $a
    next a
    unfix movegroup_fix
    jump SELF loop
    
    """
    lmp.commands_string(block7)
    

#game loop
run = True
while run:
  #wait()
  clock.tick(FPS)
 
  #update background
  screen.fill(pygame.Color("midnightblue"))

  #draw player
  player.topleft = (x, y)
  pygame.draw.rect(screen, pygame.Color(col), player)

  #show number of connected joysticks
  draw_text("Controllers: " + str(pygame.joystick.get_count()), font, pygame.Color("azure"), 10, 10)
  for joystick in joysticks:
    draw_text("Battery Level: " + str(joystick.get_power_level()), font, pygame.Color("azure"), 10, 35)
    draw_text("Controller Type: " + str(joystick.get_name()), font, pygame.Color("azure"), 10, 60)
    draw_text("Number of axes: " + str(joystick.get_numaxes()), font, pygame.Color("azure"), 10, 85)

  for joystick in joysticks:
    #change player colour with buttons
    #if joystick.get_button(0):
      #col = "royalblue"
    #if joystick.get_button(1):
      #col = "crimson"
    #if joystick.get_button(2):
      #col = "fuchsia"
    #if joystick.get_button(3):
      #col = "forestgreen"

    #player movement with joystick
    if joystick.get_button(1):
      print("button 1")
    if joystick.get_button(2):
      print("button 2")
    if joystick.get_button(3):
      print("button 3")    
    if joystick.get_button(4):
      print("button 4")
    if joystick.get_button(5):
      print("button 5")

    if joystick.get_button(9):
      print("button 9")    
    if joystick.get_button(8):
      print("button 8")            
    #if joystick.get_button(5):
      #x += 5
    #if joystick.get_button(4):
      #x -= 5
    #if joystick.get_button(3):
      #y -= 5
    #if joystick.get_button(2):
      #y += 5
    pygame.event.pump()
    #print(pygame.joystick.Joystick(0).get_axis(0)) #left and right
    #print(pygame.joystick.Joystick(0).get_axis(4)) #up and down
    
    
    #player movement with analogue sticks
    horiz_move = round(joystick.get_axis(0), 1)
    vert_move = round(joystick.get_axis(4), 1)
    
    if horiz_move == 1:
      moveposX()
    elif horiz_move == -1:
      movenegX()
    
         
    if joystick.get_button(2) and vert_move == -1  :
      moveposZ()
    elif joystick.get_button(2) and vert_move == 1  :
      movenegZ()  
    elif vert_move == -1 :
      moveposY()
    elif  vert_move == 1:
      movenegY()  
    else:
      pass     
    
    if abs(vert_move) > 0.05:
      y += vert_move * 5
      #print(vert_move)
      
    if abs(horiz_move) > 0.05:
      x += horiz_move * 5
      #print(horiz_move)
    
  #event handler
  for event in pygame.event.get():
    if event.type == pygame.JOYDEVICEADDED:
      joy = pygame.joystick.Joystick(event.device_index)
      joysticks.append(joy)
    #quit program
    if event.type == pygame.QUIT:
      run = False

  #update display
  pygame.display.flip()

pygame.quit()